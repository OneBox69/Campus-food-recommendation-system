package net.codejava.codejavaapp;

import jakarta.persistence.*;

@Entity
@Table(name = "restaurant_snake")
public class Restaurant {

    @Id
    @Column(name = "restaurant_id")
    private Integer restaurantId;

    @Column(name = "restaurant_name")
    private String restaurantName;

    @Column(name = "category")
    private String category;

    @Column(name = "rating")
    private Float rating;

    @Column(name = "average_price")
    private Integer averagePrice;

    @Column(name = "signature")
    private String signature;

    @Column(name = "signature_price")
    private Float signaturePrice;

    @Column(name = "operating_hour")
    private String operatingHour;

    @Column(name = "location_id")
    private String locationId;

    public Integer getRestaurantId() { return restaurantId; }
    public String getRestaurantName() { return restaurantName; }
    public String getCategory() { return category; }
    public Float getRating() { return rating; }
    public Integer getAveragePrice() { return averagePrice; }
    public String getSignature() { return signature; }
    public Float getSignaturePrice() { return signaturePrice; }
    public String getOperatingHour() { return operatingHour; }
    public String getLocationId() { return locationId; }
}




