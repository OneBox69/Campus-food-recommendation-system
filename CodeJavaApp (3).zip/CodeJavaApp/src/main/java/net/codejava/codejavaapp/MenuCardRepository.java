package net.codejava.codejavaapp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MenuCardRepository extends JpaRepository<MenuCard, Long> {

    @Query(value = """
        SELECT * FROM v_menu_cards
        WHERE (:category IS NULL OR :category = '' OR restaurant_category = :category)
          AND (:minRating IS NULL OR restaurant_rating >= :minRating)
          AND (:minPrice IS NULL OR restaurant_avg_price >= :minPrice)
          AND (:maxPrice IS NULL OR restaurant_avg_price <= :maxPrice)
        ORDER BY restaurant_rating DESC
        LIMIT 200
    """, nativeQuery = true)
    List<MenuCard> findForFilters(@Param("category") String category,
                                  @Param("minRating") Float minRating,
                                  @Param("minPrice") Integer minPrice,
                                  @Param("maxPrice") Integer maxPrice);
    List<MenuCard> findTop30ByRestaurantCategoryOrderByIdAsc(String restaurantCategory);
}



