package net.codejava.codejavaapp;

import jakarta.persistence.*;

@Entity
@Table(name = "location")
public class Location {

    @Id
    @Column(name = "locationid")  // ← lowercase
    private String locationId;

    @Column(name = "roadnumberandstreet")  // ← lowercase
    private String roadNumberAndStreet;

    @Column(name = "area")
    private String area;

    @Column(name = "latitude")  // ← lowercase
    private Double latitude;

    @Column(name = "longitude")  // ← lowercase
    private Double longitude;

    public String getLocationId() { return locationId; }
    public String getRoadNumberAndStreet() { return roadNumberAndStreet; }
    public String getArea() { return area; }
    public Double getLatitude() { return latitude; }
    public Double getLongitude() { return longitude; }

    public void setLocationId(String locationId) { this.locationId = locationId; }
    public void setRoadNumberAndStreet(String roadNumberAndStreet) { this.roadNumberAndStreet = roadNumberAndStreet; }
    public void setArea(String area) { this.area = area; }
    public void setLatitude(Double latitude) { this.latitude = latitude; }
    public void setLongitude(Double longitude) { this.longitude = longitude; }
}