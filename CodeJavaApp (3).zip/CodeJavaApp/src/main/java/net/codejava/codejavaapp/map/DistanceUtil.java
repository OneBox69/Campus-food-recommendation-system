package net.codejava.codejavaapp.map;

public class DistanceUtil {

    private static final double EARTH_RADIUS = 6371000; // m
    private static final double WALK_SPEED   = 1.4;    // m/s  (6 km/h)
    private static final double SCOOTER_SPEED = 4.50;   // m/s  (18 km/h)

    /** Haversine distance in meters (1-decimal). */
    public static double distanceM(double lat1, double lng1,
                                   double lat2, double lng2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(dLng / 2) * Math.sin(dLng / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double meter = EARTH_RADIUS * c;
        return Math.round(meter * 10) / 10.0; // 1-decimal
    }

    /** Walking time in minutes (1-decimal). */
    public static double walkMin(double meter) {
        return Math.round((meter / WALK_SPEED / 60) * 10) / 10.0;
    }

    /** Scooter time in minutes (1-decimal). */
    public static double scooterMin(double meter) {
        return Math.round((meter / SCOOTER_SPEED / 60) * 10) / 10.0;
    }
}
