package net.codejava.codejavaapp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface FavoriteRepository extends JpaRepository<Favorite, Long> {

    boolean existsByUserIdAndRestaurantId(Long userId, Integer restaurantId);

    @Modifying
    @Transactional
    void deleteByUserIdAndRestaurantId(Long userId, Integer restaurantId);

    List<Favorite> findByUserId(Long userId);
}
