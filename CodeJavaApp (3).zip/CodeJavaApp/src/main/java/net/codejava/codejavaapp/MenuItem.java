package net.codejava.codejavaapp;

import jakarta.persistence.*;

@Entity
@Table(name = "menu_items")
public class MenuItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "restaurant_id", nullable = false)
    private Integer restaurantId;

    @Column(name = "food_id", nullable = false)
    private Integer foodId;

    @Column(name = "food_name", nullable = false)
    private String foodName;

    @Column(name = "price")
    private Double price;

    @Column(name = "picture_url")
    private String pictureUrl;

    public Long getId() { return id; }
    public Integer getRestaurantId() { return restaurantId; }
    public Integer getFoodId() { return foodId; }
    public String getFoodName() { return foodName; }
    public Double getPrice() { return price; }
    public String getPictureUrl() { return pictureUrl; }

    public void setId(Long id) { this.id = id; }
    public void setRestaurantId(Integer restaurantId) { this.restaurantId = restaurantId; }
    public void setFoodId(Integer foodId) { this.foodId = foodId; }
    public void setFoodName(String foodName) { this.foodName = foodName; }
    public void setPrice(Double price) { this.price = price; }
    public void setPictureUrl(String pictureUrl) { this.pictureUrl = pictureUrl; }
}
