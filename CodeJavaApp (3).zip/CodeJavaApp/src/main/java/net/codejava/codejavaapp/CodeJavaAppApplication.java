package net.codejava.codejavaapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeJavaAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(CodeJavaAppApplication.class, args);
    }

}
