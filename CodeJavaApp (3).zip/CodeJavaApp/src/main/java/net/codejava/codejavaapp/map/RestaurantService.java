package net.codejava.codejavaapp.map;

import lombok.RequiredArgsConstructor;
import net.codejava.codejavaapp.Location;
import net.codejava.codejavaapp.LocationRepository;
import net.codejava.codejavaapp.RestaurantRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RestaurantService {

    private final RestaurantRepository restaurantRepo;
    private final LocationRepository locationRepo;

    /**
     * Returns all restaurants enriched with live distance & travel times
     * from the user's current lat/lng.
     */
    public List<RestaurantDto> listRestaurants(double userLat, double userLng) {
        return restaurantRepo.findAll()
                .stream()
                .filter(r -> {
                    String locId = r.getLocationId() == null ? null : r.getLocationId().trim();
                    return locId != null && !locId.isEmpty();
                })
                .map(r -> {
                    String locId = r.getLocationId().trim();
                    System.out.println("Processing restaurant ID: " + r.getRestaurantId() + " with locationId: '" + locId + "'");

                    Location loc = locationRepo.findById(locId).orElse(null);

                    if (loc == null) {
                        System.out.println("Location not found for ID: '" + locId + "' - Skipping this restaurant");

                        // Temporary: Print all available location IDs once (to avoid spamming logs)
                        if (r.getRestaurantId() == 1) {  // Only print once, for the first restaurant
                            List<String> allIds = locationRepo.findAll()
                                    .stream()
                                    .map(Location::getLocationId)
                                    .sorted()
                                    .collect(Collectors.toList());
                            System.out.println("Available location IDs in database: " + allIds);
                        }
                        return null;  // Skip this restaurant
                    }

                    // Now loc is guaranteed to be non-null
                    double m = DistanceUtil.distanceM(userLat, userLng,
                            loc.getLatitude(), loc.getLongitude());

                    String info = r.getCategory() + ", Signature: " + r.getSignature() + " (" + r.getSignaturePrice() + ")";

                    return new RestaurantDto(
                            (long) r.getRestaurantId(),
                            r.getRestaurantName(),
                            loc.getLatitude(),
                            loc.getLongitude(),
                            info,
                            m,
                            DistanceUtil.walkMin(m),
                            DistanceUtil.scooterMin(m)
                    );
                })
                .filter(dto -> dto != null)  // Remove skipped restaurants
                .collect(Collectors.toList());
    }
}