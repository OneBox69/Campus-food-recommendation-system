package net.codejava.codejavaapp.map;
import net.codejava.codejavaapp.CustomUserDetails;
import net.codejava.codejavaapp.map.RestaurantDto;
import net.codejava.codejavaapp.map.RestaurantService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/restaurants")
@RequiredArgsConstructor
public class LocationApiController {


    private final RestaurantService service;

    /**
     * Query param ?lat=...&lng=... required.
     * Returns restaurants with real-time distance & travel times.
     */
    @GetMapping
    public List<RestaurantDto> restaurants(@RequestParam double lat,
                                           @RequestParam double lng) {
        return service.listRestaurants(lat, lng);
    }
}
