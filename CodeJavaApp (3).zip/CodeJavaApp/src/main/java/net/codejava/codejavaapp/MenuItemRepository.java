package net.codejava.codejavaapp;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MenuItemRepository extends JpaRepository<MenuItem, Long> {
    List<MenuItem> findTop30ByOrderByIdAsc();
    List<MenuItem> findByRestaurantIdOrderByFoodIdAsc(Integer restaurantId);
    MenuItem findByRestaurantIdAndFoodId(Integer restaurantId, Integer foodId);
}
