package net.codejava.codejavaapp.map;

//dto - Data Transfer Object, sends from backend to frontend to enable all the distances
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RestaurantDto {
    private Long id;
    private String name;
    private Double latitude;
    private Double longitude;
    private String info;
    private Double distanceM;   // meters
    private Double walkMin;     // walking minutes
    private Double scooterMin;  // scooter minutes
}