package net.codejava.codejavaapp;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "reviews")
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "review_id")
    private Long reviewId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "restaurant_id", nullable = false)
    private Integer restaurantId;

    @Column(name = "rating", nullable = false, precision = 3, scale = 1)
    private BigDecimal rating;

    @Column(name = "comment")
    private String comment;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;

    // getters
    public Long getReviewId() { return reviewId; }
    public Long getUserId() { return userId; }
    public Integer getRestaurantId() { return restaurantId; }
    public BigDecimal getRating() { return rating; }
    public String getComment() { return comment; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    // setters
    public void setReviewId(Long reviewId) { this.reviewId = reviewId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public void setRestaurantId(Integer restaurantId) { this.restaurantId = restaurantId; }
    public void setRating(BigDecimal rating) { this.rating = rating; }
    public void setComment(String comment) { this.comment = comment; }
}
