package net.codejava.codejavaapp;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByRestaurantIdOrderByCreatedAtDesc(Integer restaurantId);

    boolean existsByUserIdAndRestaurantId(Long userId, Integer restaurantId);

    Optional<Review> findByUserIdAndRestaurantId(Long userId, Integer restaurantId);

    List<Review> findByUserIdOrderByCreatedAtDesc(Long userId);

}
