package net.codejava.codejavaapp;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FilterService {

    // "20:30" -> 1230 minutes. Returns null if empty/invalid.
    private Integer toMinutesOrNull(String hhmm) {
        if (hhmm == null) return null;
        String s = hhmm.trim();
        if (s.isEmpty()) return null;

        // accept exactly HH:mm
        if (!s.matches("\\d{2}:\\d{2}")) return null;

        int h = Integer.parseInt(s.substring(0, 2));
        int m = Integer.parseInt(s.substring(3, 5));
        return h * 60 + m;
    }

    // operatingHour can be "10:30-20:30" or "10:30-14:30,16:00-20:30"
    private int earliestOpen(String operatingHour) {
        if (operatingHour == null || operatingHour.isBlank()) return Integer.MAX_VALUE;

        int min = Integer.MAX_VALUE;
        for (String range : operatingHour.split(",")) {
            String[] parts = range.trim().split("-");
            if (parts.length != 2) continue;

            Integer start = toMinutesOrNull(parts[0].trim());
            if (start != null) min = Math.min(min, start);
        }
        return min;
    }

    private int latestClose(String operatingHour) {
        if (operatingHour == null || operatingHour.isBlank()) return -1;

        int max = -1;
        for (String range : operatingHour.split(",")) {
            String[] parts = range.trim().split("-");
            if (parts.length != 2) continue;

            Integer end = toMinutesOrNull(parts[1].trim());
            if (end != null) max = Math.max(max, end);
        }
        return max;
    }

    public List<MenuCard> filterByHours(List<MenuCard> cards, String openBy, String openUntil) {
        Integer openByMin = toMinutesOrNull(openBy);
        Integer openUntilMin = toMinutesOrNull(openUntil);

        return cards.stream()
                // if openByMin is null => no filter
                .filter(c -> openByMin == null || earliestOpen(c.getRestaurantOperatingHour()) <= openByMin)
                // if openUntilMin is null => no filter
                .filter(c -> openUntilMin == null || latestClose(c.getRestaurantOperatingHour()) >= openUntilMin)
                .toList();
    }

    public List<MenuCard> filterByTags(List<MenuCard> cards, String tagsCsv) {
        if (tagsCsv == null || tagsCsv.trim().isEmpty()) return cards;

        List<String> wanted = Arrays.stream(tagsCsv.split(","))
                .map(s -> s.trim().toLowerCase())
                .filter(s -> !s.isEmpty())
                .toList();

        return cards.stream()
                .filter(c -> tagsMatch(c.getRestaurantTags(), wanted))
                .toList();
    }

    private boolean tagsMatch(String dbTags, List<String> wanted) {
        if (dbTags == null || dbTags.isBlank()) return false;

        // Your DB looks like: ['Healthy', 'Global Cuisine', 'Good Environment']
        String cleaned = dbTags.replace("[", "")
                .replace("]", "")
                .replace("'", "")
                .replace("\"", "");

        for (String t : cleaned.split(",")) {
            String tag = t.trim().toLowerCase();
            for (String w : wanted) {
                if (tag.equals(w) || tag.contains(w)) return true;
            }
        }
        return false;
    }

}
