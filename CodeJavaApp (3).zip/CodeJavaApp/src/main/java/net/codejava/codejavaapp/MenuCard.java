package net.codejava.codejavaapp;

import jakarta.persistence.*;

@Entity
@Table(name = "v_menu_cards")
public class MenuCard {

    @Id
    private Long id;

    @Column(name="restaurant_id")
    private Integer restaurantId;

    @Column(name="food_id")
    private Integer foodId;

    @Column(name="food_name")
    private String foodName;

    private Double price;

    @Column(name="picture_url")
    private String pictureUrl;

    @Column(name="restaurant_name")
    private String restaurantName;

    @Column(name="restaurant_rating")
    private Float restaurantRating;

    @Column(name="restaurant_category")
    private String restaurantCategory;

    @Column(name="restaurant_avg_price")
    private Integer restaurantAvgPrice;

    @Column(name="restaurant_operating_hour")
    private String restaurantOperatingHour;

    @Column(name="restaurant_tags")
    private String restaurantTags;

    @Transient
    private String distance;

    public String getDistance() {
        return distance != null ? distance : "— km";
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getRestaurantTags() { return restaurantTags; }

    public Long getId() { return id; }
    public Integer getRestaurantId() { return restaurantId; }
    public Integer getFoodId() { return foodId; }
    public String getFoodName() { return foodName; }
    public Double getPrice() { return price; }
    public String getPictureUrl() { return pictureUrl; }
    public String getRestaurantName() { return restaurantName; }
    public Float getRestaurantRating() { return restaurantRating; }
    public String getRestaurantCategory() { return restaurantCategory; }
    public Integer getRestaurantAvgPrice() { return restaurantAvgPrice; }
    public String getRestaurantOperatingHour() { return restaurantOperatingHour; }
}
