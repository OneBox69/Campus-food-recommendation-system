package net.codejava.codejavaapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.Random;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Objects;
import java.util.stream.Collectors;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;


@Controller
public class AppController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private FavoriteRepository favoriteRepo;

    @Autowired
    private MenuItemRepository menuItemRepo;


    @Autowired
    private UserRepository repo;

    @Autowired
    private MenuCardRepository menuCardRepo;

    @Autowired
    private LocationRepository locationRepo;

    @Autowired
    private RestaurantRepository restaurantRepo;

    @Autowired
    private FilterService filterService;

    private static final Random random = new Random();

    @GetMapping("/")
    public String viewHomePage(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) Float minRating,
            @RequestParam(required = false) Integer minPrice,
            @RequestParam(required = false) Integer maxPrice,
            @RequestParam(required = false) String tags,
            @RequestParam(required = false) String openBy,
            @RequestParam(required = false) String openUntil,
            Model model
    ) {
        List<MenuCard> base = menuCardRepo.findForFilters(category, minRating, minPrice, maxPrice);

        List<MenuCard> filtered = filterService.filterByHours(base, openBy, openUntil);
        filtered = filterService.filterByTags(filtered, tags);

        // Add random distance to each card
        filtered.forEach(card -> {
            double randomKm = 0.5 + (random.nextDouble() * 2.5);  // 0.5km to 3.0km
            card.setDistance(String.format("%.1fkm", randomKm));
        });

        List<MenuCard> foodCards = filtered.stream()
                .filter(c -> "Food".equalsIgnoreCase(c.getRestaurantCategory()))
                .limit(30)
                .toList();

        List<MenuCard> drinkCards = filtered.stream()
                .filter(c -> "Beverage".equalsIgnoreCase(c.getRestaurantCategory()))
                .limit(30)
                .toList();

        List<Integer> fastFoodIds = List.of(5, 8, 9);
        List<MenuCard> fastFoodCards = filtered.stream()
                .filter(c -> fastFoodIds.contains(c.getRestaurantId()))
                .limit(30)
                .toList();

        model.addAttribute("foodCards", foodCards);
        model.addAttribute("drinkCards", drinkCards);
        model.addAttribute("fastFoodCards", fastFoodCards);

        model.addAttribute("category", category);
        model.addAttribute("minRating", minRating);
        model.addAttribute("minPrice", minPrice);
        model.addAttribute("maxPrice", maxPrice);
        model.addAttribute("tags", tags);
        model.addAttribute("openBy", openBy);
        model.addAttribute("openUntil", openUntil);
        model.addAttribute("page", "home");

        return "index";
    }




    @GetMapping("/register")
    public String showSignUpForm(Model model){
        model.addAttribute("user", new User());
        return "signup_form";
    }

    @GetMapping("/terms")
    public String showTermsPage(Model model){
        model.addAttribute("user", new User());
        return "terms";
    }

    @GetMapping("/privacy")
    public String showPrivacyPage(Model model){
        model.addAttribute("user", new User());
        return "privacy";
    }


    @Autowired
    private ReviewRepository reviewRepository;


    @GetMapping("/restaurant/{rid}")
    public String restaurantPage(@PathVariable("rid") Integer rid,
                                 @RequestParam(value="foodId", required=false) Integer foodId,
                                 Model model) {

        Restaurant restaurant = restaurantRepo.findById(rid)
                .orElseThrow(() -> new IllegalArgumentException("Restaurant not found: " + rid));

        String locId = restaurant.getLocationId() == null ? "" : restaurant.getLocationId().trim();

        String address = locationRepo.findRoadByLocationId(locId);
        if (address == null) address = "Unknown location";

        model.addAttribute("address", address);





        Authentication authentication = SecurityContextHolder
                .getContext()
                .getAuthentication();

        CustomUserDetails userDetails =
                (CustomUserDetails) authentication.getPrincipal();

        User currentUser = userDetails.getUser();
        Long currentUserId = currentUser.getId();

        boolean isFavourite =
                favoriteRepo.existsByUserIdAndRestaurantId(
                        currentUserId,
                        restaurant.getRestaurantId()
                );

        model.addAttribute("isFavourite", isFavourite);


        boolean hasReviewed =
                reviewRepository.existsByUserIdAndRestaurantId(currentUserId, rid);
        var menuItems = menuItemRepo.findByRestaurantIdOrderByFoodIdAsc(rid);
        var reviews = reviewRepository.findByRestaurantIdOrderByCreatedAtDesc(rid);



        // extract unique userIds from reviews
        var userIds = reviews.stream()
                .map(Review::getUserId)
                .distinct()
                .toList();

        // fetch users in one query
        var users = userRepository.findByIdIn(userIds);

        // build userId -> displayName map
        var userNameMap = users.stream()
                .collect(Collectors.toMap(
                        User::getId,
                        u -> u.getFirstName() + " " + u.getLastName()
                ));
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("hasReviewed", hasReviewed);
        model.addAttribute("userNameMap", userNameMap);
        model.addAttribute("restaurant", restaurant);
        model.addAttribute("menuItems", menuItems);
        model.addAttribute("selectedFoodId", foodId);
        model.addAttribute("reviews", reviews);
        model.addAttribute("reviewCount", reviews.size());

        model.addAttribute("existingReview",
                reviewRepository.findByUserIdAndRestaurantId(currentUserId, rid).orElse(null));

        return "restaurant";
    }

//    @GetMapping("/restaurant/{rid}/review/edit")
//    public String editReviewPage(@PathVariable("rid") Integer rid, Model model) {
//
//        Authentication authentication =
//                SecurityContextHolder.getContext().getAuthentication();
//
//        CustomUserDetails userDetails =
//                (CustomUserDetails) authentication.getPrincipal();
//
//        User currentUser = userDetails.getUser();
//
//        Review review = reviewRepository
//                .findByUserIdAndRestaurantId(currentUser.getId(), rid)
//                .orElseThrow(() -> new IllegalStateException("Review not found"));
//
//        model.addAttribute("review", review);
//        model.addAttribute("restaurantId", rid);
//
//        return "edit-review";
//    }
//
//    @PostMapping("/restaurant/{rid}/review/edit")
//    public String updateReview(@PathVariable("rid") Integer rid,
//                               @RequestParam("rating") BigDecimal rating,
//                               @RequestParam("comment") String comment) {
//
//        Authentication authentication =
//                SecurityContextHolder.getContext().getAuthentication();
//
//        CustomUserDetails userDetails =
//                (CustomUserDetails) authentication.getPrincipal();
//
//        User currentUser = userDetails.getUser();
//
//        Review review = reviewRepository
//                .findByUserIdAndRestaurantId(currentUser.getId(), rid)
//                .orElseThrow(() -> new IllegalStateException("Review not found"));
//
//        review.setRating(rating);
//        review.setComment(comment);
//
//        reviewRepository.save(review);
//
//        return "redirect:/restaurant/" + rid;
//    }

    @PostMapping("/restaurant/{rid}/review/save")
    public String saveReview(
            @PathVariable("rid") Integer rid,
            @RequestParam("rating") BigDecimal rating,
            @RequestParam(value = "comment", required = false) String comment,
            Authentication authentication) {

        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        User currentUser = userDetails.getUser();
        Long userId = currentUser.getId();

        // Try to find existing review, create new if not found
        Review review = reviewRepository.findByUserIdAndRestaurantId(userId, rid)
                .orElse(new Review());

        // Set/update fields
        review.setUserId(userId);
        review.setRestaurantId(rid);
        review.setRating(rating);
        review.setComment(comment);  // can be null/empty

        reviewRepository.save(review);

        // Redirect back to restaurant page
        return "redirect:/restaurant/" + rid;
    }


    @PostMapping("/process_register")
    public String processRegistration(User user){
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String encodedPassword = encoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
        repo.save(user);

        return"register_success";
    }

    @GetMapping("/list_users")
    public String viewUserList(Model model){
        List<User> listUsers = repo.findAll();
        model.addAttribute("listUsers", listUsers);
        return "users";
    }

    @GetMapping("/login")
    public String showLoginPage() {
        // returns src/main/resources/templates/login.html
        return "login";
    }

    @PostMapping("/restaurant/{rid}/favorite")
    public String toggleFavorite(@PathVariable("rid") Integer rid) {

        Authentication auth =
                SecurityContextHolder.getContext().getAuthentication();

        CustomUserDetails userDetails =
                (CustomUserDetails) auth.getPrincipal();

        Long userId = userDetails.getUser().getId();

        if (favoriteRepo.existsByUserIdAndRestaurantId(userId, rid)) {
            favoriteRepo.deleteByUserIdAndRestaurantId(userId, rid);
        } else {
            Favorite f = new Favorite();
            f.setUserId(userId);
            f.setRestaurantId(rid);
            favoriteRepo.save(f);
        }

        return "redirect:/restaurant/" + rid;
    }



    // Add this to any controller, e.g., MapController or a new one
    @GetMapping("/test-locations")
    @ResponseBody  // This tells Spring to return raw data, not look for a template
    public List<String> testLocations() {
        return locationRepo.findAll()
                .stream()
                .map(Location::getLocationId)
                .sorted()
                .toList();
    }

    @GetMapping("/profile")
    public String viewProfilePage(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        User currentUser = userDetails.getUser();

        String displayName = currentUser.getFirstName();
        if (displayName == null || displayName.trim().isEmpty()) {
            displayName = currentUser.getEmail().split("@")[0];
        }
        model.addAttribute("userName", displayName.trim());

        // Get favorited restaurant IDs
        List<Favorite> userFavorites = favoriteRepo.findByUserId(currentUser.getId());
        List<Integer> favoriteRestaurantIds = userFavorites.stream()
                .map(Favorite::getRestaurantId)
                .filter(Objects::nonNull)
                .toList();

        List<Restaurant> favouriteRestaurants = restaurantRepo.findAllById(favoriteRestaurantIds);

        // Fetch signature dish (food_id = 1) for each favorited restaurant
        // Create a list of wrapper objects: [MenuItem, Restaurant Name]
        List<Object[]> signatureWithName = new ArrayList<>();
        for (Restaurant restaurant : favouriteRestaurants) {
            MenuItem item = menuItemRepo.findByRestaurantIdAndFoodId(restaurant.getRestaurantId(), 1);
            if (item != null) {
                signatureWithName.add(new Object[]{item, restaurant.getRestaurantName()});
            }
        }
        model.addAttribute("signatureItems", signatureWithName);
        model.addAttribute("page", "profile");
        return "profile";
    }

    @GetMapping("/profile/reviews")
    public String viewProfileReviews(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        User currentUser = userDetails.getUser();

        String displayName = currentUser.getFirstName();
        if (displayName == null || displayName.trim().isEmpty()) {
            displayName = currentUser.getEmail().split("@")[0];
        }
        model.addAttribute("userName", displayName.trim());

        // Fixed: Use findByUserIdOrderByCreatedAtDesc (assuming your Review entity has a 'userId' field)
        List<Review> userReviews = reviewRepository.findByUserIdOrderByCreatedAtDesc(currentUser.getId());

        // Get restaurant names for each review
        List<Object[]> reviewsWithRestaurant = new ArrayList<>();
        for (Review review : userReviews) {
            Restaurant restaurant = restaurantRepo.findById(review.getRestaurantId())
                    .orElse(null);
            String restaurantName = restaurant != null ? restaurant.getRestaurantName() : "Unknown Restaurant";
            reviewsWithRestaurant.add(new Object[]{review, restaurantName});
        }

        model.addAttribute("userReviews", reviewsWithRestaurant);

        // For tab highlighting
        model.addAttribute("activeTab", "reviews");
        model.addAttribute("page", "profile");

        return "profile";  // Reuses the same profile.html template (no new page load)
    }

    @GetMapping("/account")
    public String viewAccountPage(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        User currentUser = userDetails.getUser();

        // Full name: First Name + Last Name (fallback to email prefix if missing)
        String firstName = currentUser.getFirstName() != null ? currentUser.getFirstName().trim() : "";
        String lastName = currentUser.getLastName() != null ? currentUser.getLastName().trim() : "";

        String fullName = (firstName + " " + lastName).trim();
        if (fullName.isEmpty()) {
            fullName = currentUser.getEmail().split("@")[0];
        }

        model.addAttribute("fullName", fullName.trim());
        model.addAttribute("page", "account"); // optional, for navigation highlighting

        return "account"; // → loads src/main/resources/templates/account.html
    }
}
