package net.codejava.codejavaapp;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import javax.sql.DataSource;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig {

    private final DataSource dataSource;

    public WebSecurityConfig(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Bean
    public UserDetailsService userDetailsService() {
        return new CustomUserDetailService();
    }

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService());
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authenticationProvider(authenticationProvider())
                .authorizeHttpRequests(auth -> auth
                        // allow static resources
                        .requestMatchers(
                                "/css/**",
                                "/images/**",
                                "/js/**"
                        ).permitAll()

                        // allow auth-related pages
                        .requestMatchers(
                                "/login",
                                "/register",          // signup form page (GET)
                                "/signup",            // just in case you use /signup anywhere
                                "/process_register",  // signup form POST
                                "/register_success",  // success page after register (if you have it)
                                "/terms",             // Terms and Conditions page
                                "/privacy"            // Privacy Policy page
                        ).permitAll()

                        // everything else requires login (/, /index, etc.)
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")              // custom login page
                        .loginProcessingUrl("/login")     // POST /login
                        .usernameParameter("email")       // login with email
                        .defaultSuccessUrl("/", true)     // go to home (index.html) after login
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                );

        return http.build();
    }
}